"""Admin API routes package — accessible only by ADMIN role.

Covers: merchants CRUD, PG config, transactions, payout requests,
        ad orders management, metrics, fee policies, sales assignments, landing stats.

원본 단일 파일 app/api/admin_routes.py 를 도메인별 서브 라우터로 분리했다:
- merchant_routes.py — 가맹점 CRUD, 단말기, 사용자 관리, 제휴중개몰
- pg_routes.py — PG config, pg-providers, PG 테스트
- settlement_routes.py — 정산/수수료 관련 (payout 제외)
- ad_routes.py — 광고 주문/지표/단가/플랜/집행 관련
- payout_routes.py — 페이아웃(출금) 요청 관련
- misc_routes.py — 대시보드 통계, AI 설정 등
- rewardpop_routes.py — 리워드팝 광고 자동집행 연동 설정
- keyword_routes.py — 광고 집행 키워드 관리·승인
- dispatch_routes.py — 광고 자동 집행 실행·조회
- credit_routes.py — 매장 광고비 크레딧 충전·환불
- ongi_routes.py — 온기(ONGI) QR 결제 연동 설정·결제 내역 조회
"""
from fastapi import APIRouter

from app.api.admin import (
    merchant_routes, pg_routes, settlement_routes, ad_routes, payout_routes, misc_routes,
    rewardpop_routes, keyword_routes, dispatch_routes, credit_routes, ongi_routes,
)

router = APIRouter(prefix="/api/admin", tags=["admin"])
router.include_router(merchant_routes.router)
router.include_router(pg_routes.router)
router.include_router(settlement_routes.router)
router.include_router(ad_routes.router)
router.include_router(payout_routes.router)
router.include_router(misc_routes.router)
router.include_router(rewardpop_routes.router)
router.include_router(keyword_routes.router)
router.include_router(dispatch_routes.router)
router.include_router(credit_routes.router)
router.include_router(ongi_routes.router)
